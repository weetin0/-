<?php

namespace app\api\controller;

use app\common\traits\Core;
use think\Controller;

class Base extends Controller
{
    use Core;
}
